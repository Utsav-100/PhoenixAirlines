package com.phoenixair.pojos;

import java.util.List;

public class FlightDetails {
	
	
	//instance vars.
	
	
	private int flight_id;
	private List<String> day;
	private String from_city;
	private String to_city;
	private int noofEconomySeats;
	private int noofBuisnessSeats;
	private double economyPrice;
	private double buisnessPrice;
	
	
	
	//constrr with no args
	
	
	public FlightDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public FlightDetails(int flight_id, List<String> day, String from_city, String to_city, int noofEconomySeats,
			int noofBuisnessSeats, double economyPrice, double buisnessPrice) {
		super();
		this.flight_id = flight_id;
		this.day = day;
		this.from_city = from_city;
		this.to_city = to_city;
		this.noofEconomySeats = noofEconomySeats;
		this.noofBuisnessSeats = noofBuisnessSeats;
		this.economyPrice = economyPrice;
		this.buisnessPrice = buisnessPrice;
	}
	
	
	
	
	

	public int getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}

	public List<String> getDay() {
		return day;
	}

	public void setDay(List<String> day) {
		this.day = day;
	}

	public String getFrom_city() {
		return from_city;
	}

	public void setFrom_city(String from_city) {
		this.from_city = from_city;
	}

	public String getTo_city() {
		return to_city;
	}

	public void setTo_city(String to_city) {
		this.to_city = to_city;
	}

	public int getNoofEconomySeats() {
		return noofEconomySeats;
	}

	public void setNoofEconomySeats(int noofEconomySeats) {
		this.noofEconomySeats = noofEconomySeats;
	}

	public int getNoofBuisnessSeats() {
		return noofBuisnessSeats;
	}

	public void setNoofBuisnessSeats(int noofBuisnessSeats) {
		this.noofBuisnessSeats = noofBuisnessSeats;
	}

	public double getEconomyPrice() {
		return economyPrice;
	}

	public void setEconomyPrice(double economyPrice) {
		this.economyPrice = economyPrice;
	}

	public double getBuisnessPrice() {
		return buisnessPrice;
	}

	public void setBuisnessPrice(double buisnessPrice) {
		this.buisnessPrice = buisnessPrice;
	}
	
	
	
	
	
	

	@Override
	public String toString() {
		return "FlightDetails [flight_id=" + flight_id + ", day=" + day + ", from_city=" + from_city + ", to_city="
				+ to_city + ", noofEconomySeats=" + noofEconomySeats + ", noofBuisnessSeats=" + noofBuisnessSeats
				+ ", economyPrice=" + economyPrice + ", buisnessPrice=" + buisnessPrice + "]";
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
